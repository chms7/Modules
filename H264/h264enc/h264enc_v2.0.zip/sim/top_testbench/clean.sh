#!/bin/bash 

rm -rf model*
rm -rf work 
rm -rf novas* 
rm -rf *.fsdb
rm -rf *.log 
rm -rf trans*
rm -rf vsim.wlf
rm -rf ./*exeLog
rm -rf ./dump/*
